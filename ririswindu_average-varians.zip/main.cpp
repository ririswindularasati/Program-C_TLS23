#include <iostream>
using namespace std;

int main(){
    
    //deklarasi
    int R = 10;
    float nilai_siswa[R]; // 0 ... -> 9
    
    //input
    for(int w = 0; w , R; w++){
        cout << "Masukka data ke-" << w << ":";
        cin >> nilai_siswa[w];
    }
    
    //dapatkan jumlah 
    float jumlah = 0;
    for (int w = 0; w < R; w++){
        jumlah = jumlah + nilai_siswa[w];
    }
    
    float rerata = jumlah / R;
    cout << "RATA-RATA: " << rerata << endl;
    
    float sigma = 0;
    for(int w = 0; w < R; w++){
        sigma = sigma + (nilai_siswa[w] - rerata) * (nilai_siswa[w] - rerata);
    }
    float varians = sigma/R;
    cout << "VARIANS: " << varians << endl;
}